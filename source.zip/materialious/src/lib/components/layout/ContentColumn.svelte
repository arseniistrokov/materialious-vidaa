<script lang="ts">
	import { isTvInterface } from '$lib/utils';
	import { onDestroy, onMount } from 'svelte';

	let { children } = $props();

	let largeCol = $state('2');
	let smallCol = $state('12');
	let mediumCol = $state('6');

	function checkWidth() {
		if (isTvInterface()) {
			mediumCol = '4';
			largeCol = '4';
		} else if (innerWidth <= 1750) {
			largeCol = '4';
		} else {
			largeCol = '2';
		}
	}

	onMount(() => {
		checkWidth();

		addEventListener('resize', checkWidth);
	});

	onDestroy(() => {
		removeEventListener('resize', checkWidth);
	});
</script>

<div class="s{smallCol} m{mediumCol} l{largeCol}">
	{@render children?.()}
</div>
