<script lang="ts">
	import { goto } from '$app/navigation';
	import { resolve } from '$app/paths';
	import Question from '$lib/components/Question.svelte';
	import { _ } from '$lib/i18n';
	import { isUnrestrictedPlatform, getMaterialiousBackendUrl, remoteMaterialiousSupported } from '$lib/backend';
	import { setInvidiousInstance, setMaterialiousBackend, clearCaches } from '$lib/auth';
	import { isOwnBackend } from '$lib/shared';
	import { backendInUseStore, invidiousInstanceStore, playerYouTubeJsFallback } from '$lib/store';

	const defaultInstance = !isOwnBackend()
		? 'https://invidious.materialio.us'
		: $invidiousInstanceStore;

	let usingInvidious: boolean = $state(false);
	let invidiousInstanceValid: boolean = $state(true);
	let invidiousInstance: string = $state(defaultInstance ?? '');

	let materialiousBackend: string = $state(getMaterialiousBackendUrl());
	let invalidMaterialiousBackend: boolean = $state(false);

	async function setupCompleted() {
		clearCaches();
		goto(resolve('/', {}), { replaceState: true });
	}

	async function setInvidious(event: Event) {
		event.preventDefault();

		invidiousInstanceValid = await setInvidiousInstance(invidiousInstance);

		if (!invidiousInstanceValid) {
			return;
		}

		setupCompleted();
	}

	function setYTBackend() {
		usingInvidious = false;
		backendInUseStore.set('yt');
		setupCompleted();
	}

	async function setMaterialiousInstance(event: Event) {
		event.preventDefault();
		invalidMaterialiousBackend = !(await setMaterialiousBackend(materialiousBackend));

		if (invalidMaterialiousBackend) return;

		setupCompleted();
	}
</script>

<nav class="center-align">
	<div class="setup">
		{#if !isUnrestrictedPlatform()}
			<p>
				<code>VITE_DEFAULT_INVIDIOUS_INSTANCE</code> has not been provided.
			</p>
			<p>
				Please read our <a
					href="https://github.com/Materialious/Materialious/blob/main/docs/DOCKER.md"
					referrerpolicy="no-referrer"
					class="link"
				>
					Docker guide
				</a>
				for configuring Materialious as a Invidious frontend.
			</p>
			<p>
				You will be required to reverse proxy Invidious & configure CORS too for Materialious to
				work.
			</p>

      <p>VIDAA: введите адрес доступного Invidious с разрешённым CORS. Проверка использует исходную функцию Materialious.</p>
      <form onsubmit={setInvidious}>
        <div class="field label border"><input aria-label="Invidious HTTPS URL" bind:value={invidiousInstance} name="instanceUrl" type="url" tabindex="0" /></div>
        <button type="submit">Подключить Invidious</button>
        {#if !invidiousInstanceValid}<p role="alert">API недоступен или отклонил запрос. Рабочий источник пока не подтверждён.</p>{/if}
      </form>
		{:else}
			<Question
				question={$_('initalSetup.useInvidious')}
				answers={[
					{
						text: $_('initalSetup.yes'),
						action: () => {
							usingInvidious = true;
						}
					},
					{
						text: $_('initalSetup.no'),
						action: setYTBackend
					},
					{
						text: $_('initalSetup.unsure'),
						action: setYTBackend
					}
				]}
				info={$_('initalSetup.invidiousInfo')}
			/>

			{#if usingInvidious}
				<div class="space"></div>

				<Question
					question={$_('initalSetup.useLocalFallback')}
					answers={[
						{
							text: $_('initalSetup.yes'),
							action: () => {
								playerYouTubeJsFallback.set(true);
							}
						},
						{
							text: $_('initalSetup.no'),
							action: () => {
								playerYouTubeJsFallback.set(false);
							}
						},
						{
							text: $_('initalSetup.unsure'),
							action: () => {
								playerYouTubeJsFallback.set(true);
							}
						}
					]}
					info={$_('initalSetup.localFallbackInfo')}
				/>

				<div class="space"></div>
				<h3>{$_('initalSetup.configureInstance')}</h3>
				<form onsubmit={setInvidious}>
					<nav class="center-align">
						<div
							class="field label prefix surface-container-highest"
							class:invalid={!invidiousInstanceValid && invidiousInstance !== ''}
						>
							<i>link</i>
							<input bind:value={invidiousInstance} name="instanceUrl" type="text" tabindex="0" />
							<label for="instanceUrl" tabindex="-1">{$_('layout.instanceUrl')}</label>
						</div>

						<button type="submit">
							<i>done_all</i>
						</button>
					</nav>
				</form>

				{#if remoteMaterialiousSupported()}
					<div class="space"></div>
					<h3>{$_('materialiousBackendUrl')}</h3>
					<form onsubmit={setMaterialiousInstance}>
						<nav class="center-align">
							<div
								class="field label prefix surface-container-highest"
								class:invalid={invalidMaterialiousBackend}
							>
								<i>link</i>
								<input
									bind:value={materialiousBackend}
									name="materialiousBackendUrl"
									type="text"
									tabindex="0"
								/>
								<label for="materialiousBackendUrl" tabindex="-1"
									>{$_('materialiousBackendUrl')}</label
								>
							</div>

							<button type="submit">
								<i>done_all</i>
							</button>
						</nav>
					</form>
				{/if}
			{/if}
		{/if}
	</div>
</nav>

<div style="margin-bottom: 20rem;"></div>

<style>
	.setup {
		width: 600px;
	}

	@media screen and (max-width: 600px) {
		.setup {
			width: 100%;
		}
	}
</style>
